# SentinelAI - Pixellogic Lite Demo
Limited public version with Pixellogic branding.