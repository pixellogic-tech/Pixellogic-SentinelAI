#!/usr/bin/env python3
# Simple Recon Agent (demo)
import argparse, time, json
def run_scan(network):
    print(f'[Recon] Starting simulated scan of {network}...')
    time.sleep(1)
    results = [ {'host':'192.168.1.10','port':22,'service':'ssh'}, {'host':'192.168.1.12','port':80,'service':'http'} ]
    print(f'[Recon] Found {len(results)} hosts.')
    print(json.dumps(results, indent=2))

if __name__=='__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--network', default='192.168.1.0/24')
    args = p.parse_args()
    run_scan(args.network)
