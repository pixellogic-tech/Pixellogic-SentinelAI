#!/usr/bin/env python3
# Simple Data Collector Agent (demo)
import time, os, json
def collect():
    os.makedirs('logs', exist_ok=True)
    info = {'collected_at': time.time(), 'notes':'demo data collector'}
    with open('logs/data_collector.json','w') as f:
        json.dump(info, f, indent=2)
    print('[DataCollector] Saved demo metadata to logs/data_collector.json')

if __name__=='__main__':
    collect()
