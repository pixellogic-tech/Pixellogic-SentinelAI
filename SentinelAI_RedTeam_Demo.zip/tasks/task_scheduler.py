#!/usr/bin/env python3
# Task Scheduler (demo) - runs predefined tasks sequentially
import time, subprocess
tasks = ['python agents/recon_agent.py', 'python agents/vuln_agent.py', 'python agents/data_collector.py']
for t in tasks:
    print('[Scheduler] Running:', t)
    subprocess.call(t, shell=True)
    time.sleep(0.5)
print('[Scheduler] All tasks complete.')
