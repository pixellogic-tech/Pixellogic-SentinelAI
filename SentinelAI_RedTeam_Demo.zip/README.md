# SentinelAI - Red Team Operations (Demo Package)

## Quickstart (under 10 lines)
1. Ensure Python 3.11+ is installed.
2. `git clone <repo>` or unzip this package.
3. `cd SentinelAI_RedTeam_Demo`
4. `pip install -r requirements.txt`  (if provided)
5. `python run_sentinel.py`
6. Open the dashboard URL printed by the launcher.

## What this package contains
- `SentinelAI_Full_Report.pdf` - Complete professional documentation.
- `run_sentinel.py` - Main entry point (launcher stub for demo).
- `agents/` - Recon, vuln, and data collector agent scripts.
- `dashboard/` - Dashboard entry script and simple UI assets folder.
- `tasks/` - Scheduler and predefined tasks code.
- `reports/` - Report generator and templates.
- `utils/` & `config/` - Helper utilities and JSON configuration files.

## Usage notes
- This demo package ships a clean structure (no placeholder logs). On first run, agents will create the `logs/` folder as needed.
- Edit `config/settings.json` and `config/agent_config.json` to set target ranges and scheduling options.
- `run_sentinel.py` is a launcher stub that starts sample agents and prints where to view the dashboard.

## Extending
- Drop additional agent scripts into `agents/` and register them in `config/agent_config.json`.
- Customize `reports/templates/pdf_template.html` for branded reports.

---
Prepared by Pixellogic - SentinelAI project.
