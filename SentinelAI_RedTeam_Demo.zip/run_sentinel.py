#!/usr/bin/env python3
# SentinelAI launcher (demo stub)
import time, webbrowser, os
print('Starting SentinelAI (demo stub)...')
print('Launching Recon Agent and Vulnerability Agent (simulated)...')
time.sleep(1)
print('Recon Agent: scanning 192.168.1.0/24 (simulated)')
time.sleep(1)
print('Vulnerability Agent: running CVE checks (simulated)')
time.sleep(1)
print('\nDashboard (demo) is available as a static file: dashboard/index.html')
path = os.path.abspath('dashboard/index.html')
print('Open this file in your browser to view the dashboard UI:')
print('file://' + path)
try:
    webbrowser.open('file://' + path)
except Exception:
    pass
