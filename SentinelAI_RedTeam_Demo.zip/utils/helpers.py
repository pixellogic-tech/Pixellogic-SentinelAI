# helpers.py - utility functions
def timestamp():
    import time
    return int(time.time())
