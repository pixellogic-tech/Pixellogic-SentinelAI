# network_tools.py - small helpers for demo
def is_local(ip):
    return str(ip).startswith('192.168.')
